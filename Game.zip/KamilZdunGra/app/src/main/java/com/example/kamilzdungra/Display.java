package com.example.kamilzdungra;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class Display extends AppCompatActivity {

    Button button[] = new Button[56];
    public static int[] values =  new int[56];
    Result result = new Result();


    private void gameScreen(){
        Intent intent = new Intent(Display.this,Game.class);
        startActivity(intent);
    }

    TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display);
        textView=findViewById(R.id.text_viewTimer);
        //malowanie();
        levelReader();

        new CountDownTimer(2000, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {

                textView.setText("Czas : "+millisUntilFinished/1000+"s");
            }
            @Override
            public void onFinish() {

                textView.setText("Koniec");
                gameScreen();
            }
        }.start();

    }

    public void levelReader(){

        int level = result.level;
        System.out.println(result.returnLevel() + " to nr levela");

        try {
            InputStream inputStream = getAssets().open("level" + result.returnLevel() + ".txt");
            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
            String line = reader.readLine();
            int index = 0;
            while (line != null) {
                System.out.println(line);
                values[index]= Integer.parseInt(line);
                int h = index + 1;
                String buttonId = "Button" + h;
                int resId = getResources().getIdentifier(buttonId, "id", getPackageName());
                button[index] = findViewById(resId);
                if(values[index] == 1)  {
                    button[index].setBackgroundColor(Color.parseColor("#FFFFFF"));
                }
                else if(values[index] == 2)  {
                    button[index].setBackgroundColor(Color.parseColor("#000000"));
                }
                else if(values[index] == 3)  {
                    button[index].setBackgroundColor(Color.parseColor("#FF0000"));
                }
                else if(values[index] == 4)  {
                    button[index].setBackgroundColor(Color.parseColor("#0000FF"));
                }
                else if(values[index] == 5)  {
                    button[index].setBackgroundColor(Color.parseColor("#00FF00"));
                }
                else if(values[index] == 6)  {
                    button[index].setBackgroundColor(Color.parseColor("#FFEF00"));
                }
                line = reader.readLine();
                index++;
            }
            inputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }




}
