package com.example.kamilzdungra;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class Result extends AppCompatActivity {
    TextView textView;
    Button buttonMenu;
    Button buttonNextLevel;
    public static Button[] buttons = new Button[56];
    public static Button[] Abuttons = new Button[56];
    int mistakes = 0;
    public static int level = 1;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        levelReader();
        levelWriter();

        check();

        textView = findViewById(R.id.textView2);
        buttonMenu = findViewById(R.id.button_backMenu);
        buttonNextLevel = findViewById(R.id.button_nextLevel);

        mistakesDispaly();

        for (int i = 0; i < 56; i++) {

            String buttonID = "Button" + i;
            int resID = getResources().getIdentifier(buttonID, "id", getPackageName());
            buttons[i] = findViewById(resID);
        }
        for (int i = 0; i < 56; i++) {

            String buttonID = "AButton" + i;
            int resID = getResources().getIdentifier(buttonID, "id", getPackageName());
            Abuttons[i] = findViewById(resID);
        }

        buttonMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                goToMenuButton();
            }
        });

        buttonNextLevel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gameAgain();
            }
        });

       // ButtonPaint();

    }

    public void ButtonPaint()   {
        Game game = new Game();
        int [] values = Game.wartosci;
        int kolor;
        Button bolo;
        for (int i = 0; i < 56; i++) {

            kolor = values[i];

            bolo = buttons[i];

            int h = i + 1;
            String buttonId = "Button" + h;
            //if (!((Button) v).getText().toString().equals("")) {
            //    return;
            //}
            if (kolor == 1) {
                System.out.println("pdw Bolo1");
                bolo.setBackgroundColor((Color.parseColor("#FF0000")));
            } else if (kolor == 2) {
                System.out.println("pdw Bolo2");
                bolo.setBackgroundColor((Color.parseColor("#FF0000")));
            } else if (kolor == 3) {
                System.out.println("pdw Bolo3");
                bolo.setBackgroundColor((Color.parseColor("#FF0000")));
            } else if (kolor == 4) {
                System.out.println("pdw Bolo4");
                bolo.setBackgroundColor((Color.parseColor("#FF0000")));
            } else if (kolor == 5) {
                System.out.println("pdw Bolo5");
                bolo.setBackgroundColor((Color.parseColor("#FF0000")));
            } else if (kolor == 6) {
                System.out.println("pdw Bolo6");
                bolo.setBackgroundColor((Color.parseColor("#FF0000")));
            }
        }
    }

    private void check()    {
        Display display = new Display();
        Game game = new Game();
        int [] arguments = Display.values;
        int [] values = Game.wartosci;
        for (int i = 0; i < 56; i++)    {
            if (arguments [i] != values [i])    {
                mistakes++;
            }
        }
        if (mistakes == 0)   {
            level++;
            System.out.println("Ma sie kurwa zwiekszyc " + level);
        }
        System.out.println(mistakes);
    }
    public int returnLevel()  {
        return level;
    }

    private void mistakesDispaly(){
        if (mistakes>0){
            textView.setText("Porażka!\n\nLiczba Błędów:"+mistakes);
            buttonNextLevel.setText("Spróbuj Ponownie");
        }else {
            textView.setText("Gratulacje!");
            buttonNextLevel.setText("Następny Poziom");
        }
    }

    private void goToMenuButton(){
        Intent intent = new Intent(Result.this,MainActivity.class);
        startActivity(intent);
    }
    private void gameAgain(){
        Intent intent = new Intent(Result.this,Display.class);
        startActivity(intent);
    }

    public void levelWriter() {

            Game game = new Game();
            int [] values = Game.wartosci;
            for (int index = 0; index < 56; index++){
                int h = index + 1;
                String buttonId = "AButton" + h;
                int resId = getResources().getIdentifier(buttonId, "id", getPackageName());
                Abuttons[index] = findViewById(resId);
                if (values[index] == 1) {
                    Abuttons[index].setBackgroundColor(Color.parseColor("#FFFFFF"));
                } else if (values[index] == 2) {
                    Abuttons[index].setBackgroundColor(Color.parseColor("#000000"));
                } else if (values[index] == 3) {
                    Abuttons[index].setBackgroundColor(Color.parseColor("#FF0000"));
                } else if (values[index] == 4) {
                    Abuttons[index].setBackgroundColor(Color.parseColor("#0000FF"));
                } else if (values[index] == 5) {
                    Abuttons[index].setBackgroundColor(Color.parseColor("#00FF00"));
                } else if (values[index] == 6) {
                    Abuttons[index].setBackgroundColor(Color.parseColor("#FFEF00"));
                }
            }

        }

    public void levelReader(){



        try {
            InputStream inputStream = getAssets().open("level" + returnLevel() + ".txt");
            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
            String line = reader.readLine();
            Display display = new Display();
            int index = 0;
            while (line != null) {
                System.out.println(line);
                display.values[index]= Integer.parseInt(line);
                int h = index + 1;
                String buttonId = "Button" + h;
                int resId = getResources().getIdentifier(buttonId, "id", getPackageName());
                buttons[index] = findViewById(resId);
                if(display.values[index] == 1)  {
                    buttons[index].setBackgroundColor(Color.parseColor("#FFFFFF"));
                }
                else if(display.values[index] == 2)  {
                    buttons[index].setBackgroundColor(Color.parseColor("#000000"));
                }
                else if(display.values[index] == 3)  {
                    buttons[index].setBackgroundColor(Color.parseColor("#FF0000"));
                }
                else if(display.values[index] == 4)  {
                    buttons[index].setBackgroundColor(Color.parseColor("#0000FF"));
                }
                else if(display.values[index] == 5)  {
                    buttons[index].setBackgroundColor(Color.parseColor("#00FF00"));
                }
                else if(display.values[index] == 6)  {
                    buttons[index].setBackgroundColor(Color.parseColor("#FFEF00"));
                }
                line = reader.readLine();
                index++;
            }
            inputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}