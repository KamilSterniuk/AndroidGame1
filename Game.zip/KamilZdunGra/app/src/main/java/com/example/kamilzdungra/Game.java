package com.example.kamilzdungra;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class Game extends AppCompatActivity {

    int kolor;

    public static int[] wartosci = new int[56];
    private Button[] buttons = new Button[56];
    private Button[] colorButtons = new Button[6];

    TextView textView;
    public void setWhite(View view) {
        ZmianaKoloru(1);
        Changer(0);
    }
    public void setBlack(View view) {
        ZmianaKoloru(2);
        Changer(1);
    }

    public void setRed(View view) {

        ZmianaKoloru(3);
        Changer(2);
    }

    public void setBlue(View view) {

        ZmianaKoloru(4);
        Changer(3);
    }

    public void setGreen(View view) {

        ZmianaKoloru(5);
        Changer(4);
    }

    public void setYellow(View view) {

        ZmianaKoloru(6);
        Changer(5);
    }

    public void ZmianaKoloru(int color)  {
        kolor = color;
    }

    public void Changer(int color) {

        for (int i = 0; i < 6; i++) {
            if (i == color) {
                colorButtons[i].setText(".");
            }
            else    {
                colorButtons[i].setText("");
            }
        }
    }

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        textView = findViewById(R.id.levelInfo);
        levelInfo();
        Button result = findViewById(R.id.check);
        result.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                check();
            }
        });

        for (int i = 0; i < 56; i++) {

                String buttonID = "Button" + i;
                int resID = getResources().getIdentifier(buttonID, "id", getPackageName());
                buttons[i] = findViewById(resID);
                //buttons[i].setBackgroundColor(Color.parseColor("#FFFFFF"));

        }

        int resIdWhite = getResources().getIdentifier("buttonWhite", "id", getPackageName());
        colorButtons[0] = findViewById(resIdWhite);
        int resIdBlack = getResources().getIdentifier("buttonBlack", "id", getPackageName());
        colorButtons[1] = findViewById(resIdBlack);
        int resIdRed = getResources().getIdentifier("buttonRed", "id", getPackageName());
        colorButtons[2] = findViewById(resIdRed);
        int resIdBlue = getResources().getIdentifier("buttonBlue", "id", getPackageName());
        colorButtons[3] = findViewById(resIdBlue);
        int resIdGreen = getResources().getIdentifier("buttonGreen", "id", getPackageName());
        colorButtons[4] = findViewById(resIdGreen);
        int resIdYellow = getResources().getIdentifier("buttonYellow", "id", getPackageName());
        colorButtons[5] = findViewById(resIdYellow);

        for (int i = 0; i < 6; i++) {
            colorButtons[i].setText("");
            colorButtons[i].setTextSize(50);
            colorButtons[i].setTextColor(Color.parseColor("#A9A9A9"));
        }
    }

    public void onButtonClick(View v)   {
        if (!((Button) v).getText().toString().equals(""))   {
            return;
        }
        if(kolor == 1)  {
            ((Button) v).setBackgroundColor(Color.parseColor("#FFFFFF"));

        }
        else if(kolor == 2)  {
            ((Button) v).setBackgroundColor(Color.parseColor("#000000"));
        }
        else if(kolor == 3)  {
            ((Button) v).setBackgroundColor(Color.parseColor("#FF0000"));
        }
        else if(kolor == 4)  {
            ((Button) v).setBackgroundColor(Color.parseColor("#0000FF"));
        }
        else if(kolor == 5)  {
            ((Button) v).setBackgroundColor(Color.parseColor("#00FF00"));
        }
        else if(kolor == 6)  {
            ((Button) v).setBackgroundColor(Color.parseColor("#FFEF00"));
        }
    }
    public void check()  {

        for (int i = 0; i < 56; i++) {
            int h = i + 1;
            String buttonId = "Button" + h;
            int resId = getResources().getIdentifier(buttonId, "id", getPackageName());
            buttons[i] = findViewById(resId);
            int buttonColor= ((ColorDrawable) buttons[i].getBackground()).getColor();
            int whiteColor = Color.WHITE;

            if(buttonColor==whiteColor) {
                wartosci[i] = 1;
            }
            else if(((ColorDrawable) buttons[i].getBackground()).getColor() == Color.parseColor("#000000")) {
                wartosci[i] = 2;
            }
            else if(((ColorDrawable) buttons[i].getBackground()).getColor() == Color.parseColor("#FF0000")) {
                wartosci[i] = 3;
            }
            else if(((ColorDrawable) buttons[i].getBackground()).getColor() == Color.parseColor("#0000FF")) {
                wartosci[i] = 4;
            }
            else if(((ColorDrawable) buttons[i].getBackground()).getColor() == Color.parseColor("#00FF00")) {
                wartosci[i] = 5;
            }
            else if(((ColorDrawable) buttons[i].getBackground()).getColor() == Color.parseColor("#FFEF00")) {
                wartosci[i] = 6;
            }
            else {
                System.out.println(i + ". Nie dziala");
            }
            System.out.println((i+1)+". " + wartosci[i] + " out");
        }
        System.out.println("PDW BOLO");
        goToResultButton();
    }

    private void goToResultButton(){
        try {
            FileWriter fileWriter = new FileWriter("currentLevel.txt");
            BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
            for (int value : wartosci)  {
                bufferedWriter.write(String.valueOf(value));
                bufferedWriter.newLine();
            }
            bufferedWriter.close();
            System.out.println("Plik nadpisany");
        } catch (IOException e)   {
            System.out.println("Błąd w czasie zapisywania pliku");
        }
        Intent intent = new Intent(Game.this,Result.class);
        startActivity(intent);
    }
    private void levelInfo(){
        Result result = new Result();

        textView.setText("Poziom: "+result.returnLevel());
    }

}